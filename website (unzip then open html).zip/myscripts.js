
function showMenu(){

/*if (document.getElementById("menu").style.display === "none"){
	document.getElementById("menu").style.display = "block";
}
else{
	document.getElementById("menu").style.display = "none";
}
*/
}